package embedded.cse.cau.ac.kr.test3;

/**
 * Created by caucse on 2018-01-30.
 */

public class Point {
    int x;
    int y;
    int mode;
    int dist;

    public Point(int x, int y){
        this.x = x;
        this.y = y;
        this.mode = -1;
        dist = 0;
    }
}
